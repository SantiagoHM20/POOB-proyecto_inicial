package shapes;

import java.awt.*;
import java.awt.geom.*;
import java.util.Random;

/**
 * A circle that can be manipulated and that draws itself on a canvas.
 * 
 * @author  Michael Kolling and David J. Barnes
 * @version 1.0.  (15 July 2000) 
 */

public class Circle{

    public static final double PI=3.1416;
    
    private int diameter;
    private int xPosition;
    private int yPosition;
    private String color;
    private boolean isVisible;
    private double radio;
    

    public Circle(){
        diameter = 30;
        xPosition = 20;
        yPosition = 15;
        color = "blue";
        isVisible = false;
        radio = diameter/2;
    }

    public Circle(int diameter, int xPosition, int yPosition, String color, boolean visibility){
        this.diameter = diameter;
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        this.color = color;
        this.isVisible = visibility;
        if (isVisible){
            draw();
        }
        else{
            erase();
        }
    }
       
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    /**
     *Change the position of the object
     */
    public void setPosition(int x, int y){
        erase();
        xPosition =  x;
        yPosition = y;
        draw();
    }
    
    public void makeInvisible(){
        erase();
        isVisible = false;
    }

    private void draw(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.draw(this, color, 
                new Ellipse2D.Double(xPosition, yPosition, 
                diameter, diameter));
            canvas.wait(10);
        }
    }

    private void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
    
    /**
     * Move the circle a few pixels to the right.
     */
    public void moveRight(){
        moveHorizontal(20);
    }

    /**
     * Move the circle a few pixels to the left.
     */
    public void moveLeft(){
        moveHorizontal(-20);
    }

    /**
     * Move the circle a few pixels up.
     */
    public void moveUp(){
        moveVertical(-20);
    }

    /**
     * Move the circle a few pixels down.
     */
    public void moveDown(){
        moveVertical(20);
    }

    /**
     * Move the circle horizontally.
     * @param distance the desired distance in pixels
     */
    public void moveHorizontal(int distance){
        erase();
        xPosition += distance;
        draw();
    }

    /**
     * Move the circle vertically.
     * @param distance the desired distance in pixels
     */
    public void moveVertical(int distance){
        erase();
        yPosition += distance;
        draw();
    }

    /**
     * Slowly move the circle horizontally.
     * @param distance the desired distance in pixels
     */
    public void slowMoveHorizontal(int distance){
        int delta;

        if(distance < 0) {
            delta = -1;
            distance = -distance;
        } else {
            delta = 1;
        }

        for(int i = 0; i < distance; i++){
            xPosition += delta;
            draw();
        }
    }

    /**
     * Slowly move the circle vertically
     * @param distance the desired distance in pixels
     */
    public void slowMoveVertical(int distance){
        int delta;

        if(distance < 0) {
            delta = -1;
            distance = -distance;
        }else {
            delta = 1;
        }

        for(int i = 0; i < distance; i++){
            yPosition += delta;
            draw();
        }
    }

    /**
     * Change the size.
     * @param newDiameter the new size (in pixels). Size must be >=0.
     */
    public void changeSize(int newDiameter){
        erase();
        diameter = newDiameter;
        draw();
    }

    /**
     * Change the color. 
     * @param color the new color. Valid colors are "red", "yellow", "blue", "green",
     * "magenta" and "black".
     */
    public void changeColor(String newColor){
        color = newColor;
        draw();
    }

    /**
     * Calculate the perimeter of the circle
     */
    public void perimeter(){
        double p;
        p = PI*radio*radio;
        System.out.println(p);
    }

    /**
     * Change the area of the circle operating with the value given as parameter
     * @param operator. Valid operators are "+","-","*","/"
     * @param value. The value must be >= 0.
     */
    public void change(char operator, int value){
        double Area;
        double nArea;
        int newDiameter;
        
        nArea = 0;
        Area = radio*radio*PI;
        
        if (operator == '+'){
            nArea = Area + value;
        }
        else if (operator == '-'){
            nArea = Area - value;
        }
        else if (operator == '*'){
            nArea = Area * value;
        }
        else if (operator == '/'){
            nArea = Area / value;
        }
        
        newDiameter = (int)Math.ceil((Math.sqrt(nArea / PI))*2);
        erase();
        diameter = newDiameter;
        draw();
    }
    
    /**
     * roll the times indicated. The distance y the angle of any movement is select random with minum values.
     * @param times. Int
     * @param maxDistance for choose range.
     */
    public void roll(int times, int maxDistance){
        int angle;
        int radiansAngle;
        int distance;
        int movementHorizontal;
        int movementVertical;
            
        
        while (times > 0 && maxDistance > 0){

            for (int i = 0; i <= times; i++){
                Random random = new Random();
                angle = (int) random.nextInt(91);
                radiansAngle =(int) Math.toRadians(angle);
                distance = (int) (random.nextInt(maxDistance));
                movementHorizontal = (int) (distance * Math.cos(radiansAngle));
                movementVertical = (int) (distance * Math.sin(radiansAngle));
                
                
                slowMoveHorizontal(movementHorizontal);
                slowMoveVertical(movementVertical);
                
                draw();
                
                makeVisible();
                
            }
            
            break;
            
        } 
    }  
    
    /**
     * Change slowly the diameter of the circle
     * @param newDiameter. Int
     */
    public void slowAreaGrowth (int newDiameter){
        int delta;
        
        if (newDiameter < 0){
            delta = -1;
            newDiameter = -newDiameter;
        }
        else {
            delta = 1;
        }
        
        for (int i = 0; i < newDiameter; i++){
            diameter += delta;
            draw();
        }
    }
}

