package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import domain.Tile;
import domain.Glue;


import javax.swing.JOptionPane;

public class PuzzleTest {
    
    private domain.Puzzle puzzle;

    @BeforeEach
    public void setUp() {
        char[][] tableroFinal = {{'.', '.', '.'},{'.', '.', '.'},{'.', '.', '.'}};
        char[][] tableroInicial = {{'.', '.', '.'},{'.', '.', '.'},{'.', '.', '.'}};
        puzzle = new domain.Puzzle(tableroInicial, tableroFinal);      
    }

    @Test
    public void shouldCreatePuzzleWithGivenHeightAndWidth() {
        int height = 3;
        int width = 3;

        domain.Puzzle newPuzzle = new domain.Puzzle(height, width);

        assertNotNull(newPuzzle); 
        assertEquals(height, newPuzzle.getHeight()); 
        assertEquals(width, newPuzzle.getWeight()); 
        assertNotNull(newPuzzle.getStarting());
        assertNotNull(newPuzzle.getEnding()); 
    }
    
    @Test
    public void shouldNotCreatePuzzleWithNegativeDimensions() {
        int height = -1;
        int width = -1;

        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new domain.Puzzle(height, width);
        });

        assertEquals("Las dimensiones deben ser positivas", exception.getMessage());
    }
    

    @Test
    public void shouldCreatePuzzleWithFinalBoardOnly() {
        char[][] finalBoard = {{'.', '.', '.'}, {'.', 'r', '.'}, {'.', '.', '.'}};

        domain.Puzzle newPuzzle = new domain.Puzzle(finalBoard);

        assertNotNull(newPuzzle); 
        assertNotNull(newPuzzle.getEnding());
        assertNotNull(newPuzzle.getStarting()); 
    }
    
    @Test
    public void shouldNotCreatePuzzleWithNullFinalBoard() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new domain.Puzzle((char[][]) null);
        });

        assertEquals("El tablero final no puede ser nulo", exception.getMessage());
    }
    

    @Test
    public void shouldAddTileWhenPositionIsFree() {
        int row = 1;
        int column = 1;
        char tileChar = 'r'; 

        puzzle.addTile(row, column, tileChar);

        assertNotNull(puzzle.getStarting()[row][column]); 
    }
    
    

    @Test
    public void shouldNotAddTileWhenPositionIsOccupied() {
        int row = 1;
        int column = 1;
        char tileChar = 'r'; 
    
        puzzle.addTile(row, column, tileChar);
        
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            puzzle.addTile(row, column, 'g');
        });
    
        assertEquals("Posición ya ocupada.", exception.getMessage());
    
        assertEquals(50, puzzle.getStarting()[row][column].getXPosition()); 
        assertEquals(50, puzzle.getStarting()[row][column].getYPosition()); 
    }
    

   @Test
    public void shouldNotAddTileWhenPositionIsOutOfBounds() {
        int row = -1; 
        int column = 1;
        char tileChar = 'r';
    
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            puzzle.addTile(row, column, tileChar);
        });
    
        assertEquals("Coordenadas fuera de los límites del tablero.", exception.getMessage());
    }

    @Test
    public void shouldNotAddTileWhenColumnIsOutOfBounds() {
        int row = 1;
        int column = 4; 
        char tileChar = 'r';
    
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            puzzle.addTile(row, column, tileChar);
        });
    
        assertEquals("Coordenadas fuera de los límites del tablero.", exception.getMessage());
    }
   
     @Test
    public void shouldDeleteTileWhenPositionIsOccupied() {
        int row = 1;
        int column = 1;
        char tileChar = 'r';

      
        puzzle.addTile(row, column, tileChar);
        
        puzzle.deleteTile(row, column);

        assertNull(puzzle.getStarting()[row][column]); 
    }
 
    @Test
public void shouldNotDeleteTileWhenPositionIsEmpty() {
    int row = 1;
    int column = 1;

    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        puzzle.deleteTile(row, column);
    });

    assertEquals("No hay ficha en la posición indicada.", exception.getMessage());
}


@Test
public void shouldNotDeleteTileWhenPositionIsOutOfBounds() {
    int row = -1; 
    int column = 1;

    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        puzzle.deleteTile(row, column);
    });

    assertEquals("Coordenadas fuera de los límites del tablero.", exception.getMessage());
}

    @Test
public void shouldNotDeleteTileWhenColumnIsOutOfBounds() {
    int row = 1;
    int column = 4; 

    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        puzzle.deleteTile(row, column);
    });

    assertEquals("Coordenadas fuera de los límites del tablero.", exception.getMessage());
}
    

@Test
public void shouldNotAddGlueIfTileIsAlreadyGlued() {
 
    puzzle.addTile(0, 0, 'r'); 

 
    puzzle.addGlue(0, 0); 

   
    assertTrue(Glue.isGlued(puzzle.getStarting()[0][0]));

 
    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        puzzle.addGlue(0, 0);
    });

   
    assertEquals("La ficha ya está pegada", exception.getMessage());
}

    @Test
public void shouldNotAddGlueWhenPositionIsOutOfBounds() {
    int row = -1; 
    int column = 0;

   
    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        puzzle.addGlue(row, column);
    });


    assertEquals("La posición no es parte del tablero", exception.getMessage());
}
    @Test
    public void shouldCreateHoleAtValidPosition() {
        puzzle.makeHole(1, 1);
        assertNotNull(puzzle.getStarting()[1][1]);
        assertEquals("hole", puzzle.getStarting()[1][1].getTypet());
    }
    
    @Test
public void shouldNotCreateHoleIfAlreadyExists() {
    puzzle.makeHole(1, 1);

   
    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        puzzle.makeHole(1, 1);
    });

  
    assertEquals("Ya hay un hueco en esta posición.", exception.getMessage());
}
    
    
   @Test
public void shouldNotCreateHoleWhenPositionIsOutOfBounds() {
    int row = 3;
    int column = 3;

   
    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        puzzle.makeHole(row, column);
    });

    
    assertEquals("Coordenadas fuera de los límites del tablero.", exception.getMessage());
}
    
    @Test
    public void shouldRelocateTileToValidPosition() {
        puzzle.addTile(1, 1, 'r');
        int[] from = {1, 1};
        int[] to = {1, 2};
        puzzle.relocate(from, to);
        
        assertNull(puzzle.getStarting()[1][1]);
        assertNotNull(puzzle.getStarting()[1][2]);
    }
    
    
    @Test
public void shouldNotRelocateIfSourceIsEmpty() {
    int[] from = {1, 1};
    int[] to = {1, 2};

    
    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        puzzle.relocate(from, to);
    });

   
    assertEquals("No hay ficha en la posición de origen.", exception.getMessage());
}
    
    
@Test
public void shouldNotRelocateToOccupiedPosition() {
    puzzle.addTile(1, 1, 'r');
    puzzle.addTile(1, 2, 'g');
    int[] from = {1, 1};
    int[] to = {1, 2};

  
    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        puzzle.relocate(from, to);
    });

  
    assertEquals("La posición de destino está ocupada.", exception.getMessage());

 
    assertEquals("ficha", puzzle.getStarting()[1][1].getTypet());
    assertEquals("ficha", puzzle.getStarting()[1][2].getTypet());
}
    
    
@Test
public void shouldRelocateToHole() {
    puzzle.addTile(1, 1, 'r');
    puzzle.makeHole(1, 2);
    int[] from = {1, 1};
    int[] to = {1, 2};

  
    puzzle.relocate(from, to);

    
    assertNull(puzzle.getStarting()[1][1]);

   
    assertNotNull(puzzle.getStarting()[1][2]);
    assertEquals("hole", puzzle.getStarting()[1][2].getTypet());
}
    
    @Test
public void shouldNotRelocateWhenPositionsAreOutOfBounds() {
    int[] from = {3, 3};
    int[] to = {1, 2};

    
    Exception exception = assertThrows(IllegalArgumentException.class, () -> {
        puzzle.relocate(from, to);
    });

  
    assertEquals("Coordenadas fuera de los límites del tablero.", exception.getMessage());
}
   
    @Test
    public void shouldExchangeTilesBetweenBoards() {
        puzzle.addTile(1, 1, 'r');
        puzzle.addTile(2, 2, 'g');
        puzzle.makeHole(1, 2);
        puzzle.makeHole(2, 1);
        
        puzzle.exchange();
        
        assertNull(puzzle.getStarting()[1][1]);
        assertNull(puzzle.getStarting()[2][2]);
        assertNotNull(puzzle.getEnding()[1][2]);
        assertNotNull(puzzle.getEnding()[2][1]);
    }
     
    
    /**
     * @Test
    public void shouldNotChangePositionsIfBothBoardsAreEmpty() {
        puzzle.exchange();
        
        assertNull(puzzle.getStarting()[0][0]);
        assertNull(puzzle.getEnding()[0][0]);
    }**/
    
    
    
    @Test
    public void shouldKeepTilesInCorrectPositionsAfterExchange() {
        puzzle.addTile(0, 0, 'r');
        puzzle.addTile(1, 1, 'g');
        
        puzzle.exchange();
        
        assertEquals("ficha", puzzle.getEnding()[0][0].getTypet());
        assertEquals("ficha", puzzle.getEnding()[1][1].getTypet());
    }
    
    @Test
    public void shouldTiltLeftWhenItMinimizesMisplacedTiles() {
        char[][] tableroInicial = {{'.', '.', '.'},{'.', 'r', '.'},{'.', '.', '.'}};
        char[][] tableroFinal = {{'.', '.', '.'},{'r', '.', '.'},{'.', '.', '.'}};
        puzzle = new domain.Puzzle(tableroInicial, tableroFinal); 
        puzzle.tilt();
    
        assertNotNull(puzzle.getStarting()[1][0]);
    } 
    
    
    @Test
    public void shouldTiltRightWhenItMinimizesMisplacedTiles() {
        char[][] tableroInicial = {{'.', '.', '.'},{'.', 'r', '.'},{'.', '.', '.'}};
        char[][] tableroFinal = {{'.', '.', '.'},{'.', '.', 'r'},{'.', '.', '.'}};
        puzzle = new domain.Puzzle(tableroInicial, tableroFinal); 
        puzzle.tilt();
    
        assertNotNull(puzzle.getStarting()[1][2]);
    }
    
    @Test
    public void shouldTiltUpWhenItMinimizesMisplacedTiles() {
        char[][] tableroInicial = {{'.', '.', '.'},{'.', 'r', '.'},{'.', '.', '.'}};
        char[][] tableroFinal = {{'.', 'r', '.'},{'.', '.', '.'},{'.', '.', '.'}};
        puzzle = new domain.Puzzle(tableroInicial, tableroFinal); 
        puzzle.tilt();
    
        assertNotNull(puzzle.getStarting()[0][1]);
    }
    
    @Test
    public void shouldTiltDownWhenItMinimizesMisplacedTiles() {
        char[][] tableroInicial = {{'.', '.', '.'},{'.', 'r', '.'},{'.', '.', '.'}};
        char[][] tableroFinal = {{'.', '.', '.'},{'.', '.', '.'},{'.', 'r', '.'}};
        puzzle = new domain.Puzzle(tableroInicial, tableroFinal); 
        puzzle.tilt();
    
        assertNotNull(puzzle.getStarting()[2][1]);
    }
   
    
    @Test
    public void shouldNotTiltIfAllTilesAreInCorrectPosition() {
        char[][] tableroInicial = {{'.', '.', '.'},{'.', 'r', '.'},{'.', '.', '.'}};
        char[][] tableroFinal = {{'.', '.', '.'},{'.', 'r', '.'},{'.', '.', '.'}};
        puzzle = new domain.Puzzle(tableroInicial, tableroFinal); 
        puzzle.tilt();
    
        assertNotNull(puzzle.getStarting()[1][1]);
    }
     
    @Test
    public void shouldTiltLeftAndMoveTiles() {
        puzzle.addTile(1, 2, 'a');
        puzzle.addTile(1, 1, 'b');
        puzzle.tilt('l');
    
        assertNull(puzzle.getStarting()[1][2]);
        assertNotNull(puzzle.getStarting()[1][1]);
        assertNotNull(puzzle.getStarting()[1][0]);
    }
   
    
    @Test
    public void shouldTiltRightAndMoveTiles() {
        puzzle.addTile(1, 0, 'a');
        puzzle.addTile(1, 1, 'b');
        puzzle.tilt('r');
    
        assertNull(puzzle.getStarting()[1][0]);
        assertNotNull(puzzle.getStarting()[1][1]);
        assertNotNull(puzzle.getStarting()[1][2]);
    }
     
    @Test
    public void shouldTiltUpAndMoveTiles() {
        puzzle.addTile(2, 0, 'a');
        puzzle.addTile(1, 0, 'b');
        puzzle.tilt('u');
    
        assertNull(puzzle.getStarting()[2][0]);
        assertNotNull(puzzle.getStarting()[1][0]);
        assertNotNull(puzzle.getStarting()[0][0]);
    }
     
    @Test
    public void shouldTiltDownAndMoveTiles() {
        puzzle.addTile(0, 0, 'a');
        puzzle.addTile(1, 0, 'b');
        puzzle.tilt('d');
    
        assertNull(puzzle.getStarting()[0][0]);
        assertNotNull(puzzle.getStarting()[1][0]);
        assertNotNull(puzzle.getStarting()[2][0]);
    }
     
    @Test
    public void shouldNotTiltIfNoTilesCanMove() {
        puzzle.addTile(1, 0, 'a');
        puzzle.addTile(1, 1, 'b');
        puzzle.tilt('l');
    
        assertEquals('a', puzzle.getStarting()[1][0].getType());
        assertEquals('b', puzzle.getStarting()[1][1].getType());
    }
     
    @Test
    public void shouldCountMisplacedTiles() {
        char[][] tableroInicial = {{'.', '.', '.'},{'.', 'r', '.'},{'.', '.', 'b'}};
        char[][] tableroFinal = {{'.', '.', '.'},{'.', 'r', '.'},{'.', '.', '.'}};
        puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    
        int misPlacedCount = puzzle.misPlacedTiles();
    
        assertEquals(1, misPlacedCount);
    }
     
    @Test
    public void shouldReturnZeroIfAllTilesAreCorrect() {
        char[][] tableroInicial = {{'.', 'x', '.'},{'.', 'r', '.'},{'.', 'a', 'b'}};
        char[][] tableroFinal = {{'.', 'x', '.'},{'.', 'r', '.'},{'.', 'a', 'b'}};
        puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    
        int misPlacedCount = puzzle.misPlacedTiles();
    
        assertEquals(0, misPlacedCount);
    }
     
    @Test
    public void shouldReturnCorrectCountWithHolesTiles() {
        char[][] tableroInicial = {{'.', 'x', '.'},{'.', 'r', '.'},{'.', 'a', 'b'}};
        char[][] tableroFinal = {{'.', 'x', '.'},{'.', 'r', '.'},{'.', 'a', 'b'}};
        puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
        puzzle.makeHole(0,0);
        puzzle.makeHole(0,2);
    
        int misPlacedCount = puzzle.misPlacedTiles();
    
        assertEquals(2, misPlacedCount);
    }
    
    public void shouldReturnTrueWhenBoardsMatch() {
        puzzle.addTile(0, 0, 'r');
        puzzle.addTile(0, 1, 'b');
        puzzle.addTile(1, 0, 'g');
    
        puzzle.getEnding()[0][0] = new domain.Tile(50, 50, 0, 0, "red", 'r');
        puzzle.getEnding()[0][1] = new domain.Tile(50, 50, 0, 50, "blue", 'b');
        puzzle.getEnding()[1][0] = new domain.Tile(50, 50, 0, 100, "green", 'b');
    
        boolean result = puzzle.isGoal();
    
        assertTrue(result);
    }
    
    @Test
    public void shouldReturnFalseWhenTilesAreMissing() {
        puzzle.addTile(0, 0, 'a');
        
        puzzle.getEnding()[0][0] = new domain.Tile(50, 50, 0, 0, "red", 'a');
        puzzle.getEnding()[0][1] = new domain.Tile(50, 50, 0, 50, "blue", 'b'); 
    
        boolean result = puzzle.isGoal();
    
        assertFalse(result);
    }
    
    @Test
    public void shouldReturnFalseWhenTilesDoNotMatch() {
        puzzle.addTile(0, 0, 'a');
        puzzle.addTile(0, 1, 'a');
    
        puzzle.getEnding()[0][0] = new domain.Tile(50, 50, 0, 0, "red", 'a');
        puzzle.getEnding()[0][1] = new domain.Tile(50, 50, 0, 50, "blue", 'c'); 
    
        boolean result = puzzle.isGoal();
    
        assertFalse(result);
    }
    
    /**@Test
    public void shouldReturnTrueWhenBothBoardsAreEmpty() {
        boolean result = puzzle.isGoal();
        assertTrue(result);
    }**/
    
    public void shouldTerminateProgram() {

        SecurityManager securityManager = new SecurityManager() {
            @Override
            public void checkPermission(java.security.Permission perm) {
                if (perm.getName().equals("exitVM.0")) {
                    throw new SecurityException("System.exit() called");
                }
            }
        };
        
        System.setSecurityManager(securityManager);
    
        try {
            puzzle.finish();
            fail("Se esperaba una excepción de seguridad debido a System.exit()");
        } catch (SecurityException e) {
       
        } finally {
            System.setSecurityManager(null); 
        }
    }
@Test
public void shouldReturnCurrentArrangement() {
    char[][] tableroInicial = {{'.', 'x', '.'},{'.', 'r', '.'},{'.', 'a', 'b'}};
    char[][] tableroFinal = {{'.', 'x', '.'},{'.', 'r', '.'},{'.', 'a', 'b'}};
    domain.Puzzle actualArrangement = new domain.Puzzle(tableroInicial, tableroFinal);
    
    char[][] expectedTableroInicial = {{'.', 'x', '.'},{'.', 'r', '.'},{'.', 'a', 'b'}};
    char[][] expectedTableroFinal = {{'.', 'x', '.'},{'.', 'r', '.'},{'.', 'a', 'b'}};
    domain.Puzzle expectedArrangement = new domain.Puzzle(expectedTableroInicial, expectedTableroFinal);
    
    assertArrayEquals(expectedArrangement.actualArrangement(), actualArrangement.actualArrangement());
}
    
    
    @Test
public void shouldMakeAllTilesVisible() {
    puzzle.addTile(0, 0, 'r');
    puzzle.addTile(1, 1, 'b');
    
    puzzle.makeVisible();
    
    assertTrue(puzzle.isVisible(puzzle.actualArrangement()[0][0]));
    assertTrue(puzzle.isVisible(puzzle.actualArrangement()[1][1]));
}
    
    @Test
    public void shouldMakeAllTilesInvisible() {
      
        puzzle.addTile(0, 0, 'r');
        puzzle.addTile(1, 1, 'b');
        puzzle.makeVisible();
    
        puzzle.makeInvisible();
    
        assertFalse(puzzle.isVisible(puzzle.actualArrangement()[0][0]));
        assertFalse(puzzle.isVisible(puzzle.actualArrangement()[1][1]));
    }
    
    @Test
public void shouldCalculateInmovilizedTiles() {
    char[][] tableroInicial = {
        {'g', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    
    int[][] expectedFixedTiles = {
        {0, 0}
    };

    int[][] actualFixedTiles = puzzle.fixedTiles();

    assertArrayEquals(expectedFixedTiles, actualFixedTiles);
}

    @Test
public void shouldNotCalculateInmovilizedTiles() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    
    int[][] expectedFixedTiles = {};

    int[][] actualFixedTiles = puzzle.fixedTiles();

    assertArrayEquals(expectedFixedTiles, actualFixedTiles);
}

@Test
public void shouldAddFreelanceTile() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Freelance", 0, 0);
    
    Tile expectedTile = new Tile("Freelance", 50, 50, 0, 0, "colorForT", 't');
    Tile actualTile = puzzle.actualArrangement()[0][0];
    
    assertEquals("Freelance", puzzle.getStarting()[0][0].getTypet());
    assertNotNull(puzzle.getStarting()[0][0]);
}

@Test
public void shouldAddRoughTile() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Rough", 0, 0);
    
    Tile expectedTile = new Tile("Rough", 50, 50, 50, 50, "colorForE", 'e');
    Tile actualTile = puzzle.actualArrangement()[0][0];
    
    assertEquals("Rough", puzzle.getStarting()[0][0].getTypet());
    assertNotNull(puzzle.getStarting()[0][0]);
}

@Test
public void shouldAddFixedTile() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Fixed", 0, 0);
    
    Tile expectedTile = new Tile("Fixed", 50, 50, 100, 100, "colorForZ", 'z');
    Tile actualTile = puzzle.actualArrangement()[0][0];
    
    assertEquals("Fixed", puzzle.getStarting()[0][0].getTypet());
    assertNotNull(puzzle.getStarting()[0][0]);
}
    
@Test
public void shouldAddFlyingTile() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Flying", 0, 0);
    
    Tile expectedTile = new Tile("Flying", 50, 50, 100, 0, "colorForS", 's');
    Tile actualTile = puzzle.actualArrangement()[0][0];
    
    assertEquals("Flying", puzzle.getStarting()[0][0].getTypet());
    assertNotNull(puzzle.getStarting()[0][0]);
}

@Test
public void shouldAddInvisibleTile() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Invisible", 0, 0);
    
    Tile expectedTile = new Tile("Invisible", 50, 50, 0, 50, "black", 'b');
    assertEquals("Invisible", puzzle.getStarting()[0][0].getTypet());
    assertNotNull(puzzle.getStarting()[0][0]);
}

@Test
public void shouldNotCreateInvalidTile() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    

    try {
        puzzle.addTile("InvalidType", 0, 0);
        fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
        assertEquals("Tipo de ficha inválido.", e.getMessage());
    }
    
  
    assertNull(puzzle.getStarting()[0][0]);
}

@Test
public void shouldNotDeleteFixed() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Fixed", 1, 1);
    
 
    try {
        puzzle.deleteTile(1, 1);
        fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
        assertEquals("La ficha es de tipo Fixed y no puede ser eliminada", e.getMessage());
    }
    
    
    assertNotNull(puzzle.actualArrangement()[1][1]);
}
    
@Test
public void shouldNotRelocateFixed() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Fixed", 1, 1);
    
   
    try {
        puzzle.relocate(new int[]{1, 1}, new int[]{0, 0});
        fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
        assertEquals("La ficha es de tipo Fixed y no puede ser reubicada", e.getMessage());
    }
    
  
    assertNotNull(puzzle.actualArrangement()[1][1]);
    assertNull(puzzle.actualArrangement()[0][0]);
}

@Test
public void shouldNotTiltRough() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', 'e', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Rough", 2, 2);
    

    Tile roughTile = puzzle.actualArrangement()[2][2];
    
   
    puzzle.tilt('l');
    puzzle.tilt('r');
    puzzle.tilt('u');
    puzzle.tilt('d');
    
  
    assertEquals(roughTile, puzzle.actualArrangement()[2][2]);

}


@Test
public void shouldRelocateRough() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Rough", 1, 1);
    
   
    Tile roughTile = puzzle.actualArrangement()[1][1];
    assertNotNull(roughTile);
   
    puzzle.relocate(new int[]{1, 1}, new int[]{0, 0});
    
    
    assertNull(puzzle.actualArrangement()[1][1]);
    assertEquals(roughTile, puzzle.actualArrangement()[0][0]);
}

@Test
public void shouldNotGlueFreelance() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Freelance", 1, 1);
    
    
    try {
        puzzle.addGlue(1, 1);
        fail("Expected IllegalArgumentException to be thrown");
    } catch (IllegalArgumentException e) {
        assertEquals("Freelance no puede ser pegada", e.getMessage());
    }
    
    
    assertFalse(puzzle.actualArrangement()[1][1].isGlued());
    assertNotNull(puzzle.actualArrangement()[1][1]);
}

@Test
public void shouldNotDeleteFlyingInHole() {
    char[][] tableroInicial = {
        {'.', '.', '.'},
        {'.', '.', '.'},
        {'.', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', '.', '.'},
        {'.', '.', '.'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Flying", 0, 1);
    puzzle.makeHole(2,1);
    
   
    
   
    puzzle.tilt('d');
    

    assertNotNull(puzzle.getStarting()[2][1]);
    assertEquals("Flying", puzzle.getStarting()[2][1].getTypet());
}

@Test
public void shouldNotNullInvisibleTile() {
    char[][] tableroInicial = {
        {'.', 'r', 'b'},
        {'b', '.', '.'},
        {'r', '.', '.'}
    };
    char[][] tableroFinal = {
        {'.', '.', '.'},
        {'.', 'r', '.'},
        {'.', '.', 'b'}
    };
    domain.Puzzle puzzle = new domain.Puzzle(tableroInicial, tableroFinal);
    puzzle.addTile("Invisible", 1, 1);
    
  
    assertNotNull(puzzle.getStarting()[1][1]);
    
    
    assertEquals("Invisible", puzzle.getStarting()[1][1].getTypet());
}
}