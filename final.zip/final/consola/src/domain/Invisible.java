package domain;

public class Invisible extends Tile {

    /**
     * Constructor para crear un agujero.
     *
     * @param width       Ancho del agujero.
     * @param height      Altura del agujero.
     * @param xPosition   Posición en el eje X.
     * @param yPosition   Posición en el eje Y.
     */
    public Invisible(int width, int height, int xPosition, int yPosition) {
        super(width, height, xPosition, yPosition, "black", 'b');
        setTypet("Invisible");
    }
}

