package domain;

import shapes.Circle;

/**
 * Write a description of class Freelance here.
 * 
 */
public class Freelance extends Tile {
    private Circle tinyCircle;

    /**
     * Constructor para crear una Tile de tipo Freelance
     * No se pega
     *
     * @param width       Ancho del agujero.
     * @param height      Altura del agujero.
     * @param xPosition   Posición en el eje X.
     * @param yPosition   Posición en el eje Y.
     */
    public Freelance(int width, int height, int xPosition, int yPosition) {
        super(width, height, xPosition, yPosition, "gray", 'f');
        setTypet("Freelance");
        createFreelanceCircle();
    }

    /**
     * Crea un pequeño círculo dentro de la ficha Freelance.
     */
    private void createFreelanceCircle() {
        int x = getXPosition() + (getWidth() - 10) / 2;
        int y = getYPosition() + (getHeight() - 10) / 2;
        tinyCircle = new Circle(10, x, y, "blue", false); // Crear el círculo sin hacerlo visible
        tinyCircle.makeVisible(); // Hacer visible el círculo inmediatamente después de crearlo
    }

    @Override
    public void relocate(int newX, int newY) {
        if (tinyCircle != null) {
            tinyCircle.makeInvisible(); // Borra el círculo antes de mover la ficha
        }
        super.relocate(newX, newY);
        if (tinyCircle != null) {
            int x = newX + (getWidth() - 10) / 2;
            int y = newY + (getHeight() - 10) / 2;
            tinyCircle.setPosition(x, y);
            tinyCircle.makeVisible(); // Vuelve a hacer visible el círculo en la nueva posición
        }
    }

}
