package domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;
import java.util.Iterator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;
import java.util.Arrays;


/**
 * Clase que representa el juego de rompecabezas.
 * 
 * Esta clase gestiona la lógica del juego, incluyendo el estado inicial y final
 * del tablero, así como las operaciones de movimiento y verificación de 
 * condiciones del juego.
 * 
 * @autor Artega-Hurtado
 */
public class Puzzle {
    private int w;
    private int h;
    private Tile[][] starting; 
    private Tile[][] ending;  
    private char[][] tablero_inicial;
    private char[][] tablero_final;
    private ArrayList<ArrayList<Tile>> glue;
    private shapes.Rectangle initialBoard; 
    private shapes.Rectangle finalBoard;
    private Map<String, Integer> moveCountMap = new HashMap<>();
    private final char[] colors = {'a', 'b', 'c', 'd', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 'u', 'v', 'w', 'x', 'y'};
    private ArrayList<int[]> holesToRestore = new ArrayList<>();
    private boolean isVisible = false;
    public Puzzle(int h, int w) {
             if (h <= 0 || w <= 0) {
            throw new IllegalArgumentException("Las dimensiones deben ser positivas");
        }
        
        this.h = h;
        this.w = w;
        this.starting = new Tile[h][w]; 
        this.ending = new Tile[h][w];
        this.glue = new ArrayList<>();
        PuzzleBoardInitializer.initializeStartingBoard(this.starting, h, w);
        PuzzleBoardInitializer.initializeEndingBoard(this.ending, h, w);
        
        int color = 0;
        
        for (int i = 0; i < h; i++){
            for (int j = 0; j < w; j++){
                addTile(i, j, colors[color % colors.length]);
                color++;
            }
        }
        exchange();
        int color2 = 0;
        for (int i = 0; i < h; i++){
            for (int j = 0; j < w; j++){
                addTile(i, j, colors[color2 % colors.length]);
                color2++;
            }
        }
        isVisible = true;
    }

    public Puzzle(char[][] tablero_inicial, char[][] tablero_final) {
        if (tablero_inicial == null || tablero_final == null) {
            throw new IllegalArgumentException("Los tableros inicial y final no pueden ser nulos");
        }
        this.h = tablero_inicial.length; 
        this.w = tablero_inicial[0].length;
        this.tablero_inicial = new char[h][w];
        this.tablero_final = new char[h][w];
        this.glue = new ArrayList<>();
        
        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {
                this.tablero_inicial[row][column] = tablero_inicial[row][column];
                this.tablero_final[row][column] = tablero_final[row][column];
            }
        }
        this.starting = new Tile[h][w];
        this.ending = new Tile[h][w];
    
        
        PuzzleBoardInitializer.convertCharsToStartingTiles(this.tablero_inicial, this.starting, h, w);
        PuzzleBoardInitializer.convertCharsToEndingTiles(this.tablero_final, this.ending, h, w);
        makeVisible();
    }

    public Puzzle(char[][] tablero_final){
        if (tablero_final == null) {
            throw new IllegalArgumentException("El tablero final no puede ser nulo");
        }    
        this.h = tablero_final.length;
        this.w = tablero_final[0].length;
        this.tablero_final = new char[h][w];
        this.tablero_inicial = new char[h][w];  
        this.glue = new ArrayList<>();

        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {
                this.tablero_final[row][column] = tablero_final[row][column];
                this.tablero_inicial[row][column] = '.'; 
            }
        }

        this.starting = new Tile[h][w];
        this.ending = new Tile[h][w];

        PuzzleBoardInitializer.initializeStartingBoard(this.starting, h, w);
        PuzzleBoardInitializer.convertCharsToEndingTiles(this.tablero_final, this.ending, h, w);
        makeVisible();
    }



    /**
     * Añade una ficha en la posición especificada del tablero inicial.
     * Verifica que la posición no esté ocupada y que esté dentro de los límites del tablero.
     *
     * @param row la fila donde se añadirá la ficha
     * @param column la columna donde se añadirá la ficha
     * @param tileChar el carácter que representa la ficha
     */
    public void addTile(int row, int column, char tileChar) {
    if (row < 0 || row >= h || column < 0 || column >= w) {
        throw new IllegalArgumentException("Coordenadas fuera de los límites del tablero.");
    }
    if (starting[row][column] != null) {
        throw new IllegalArgumentException("Posición ya ocupada.");
    }
    String color = PuzzleBoardInitializer.getColorForTile(tileChar);
    Tile tile = new Tile(50, 50, column * 50, row * 50, color, tileChar);
    tile.makeVisible();
    starting[row][column] = tile; 
}
    
    /**
 * Añade una ficha en la posición especificada del tablero inicial.
 * Verifica que la posición no esté ocupada, que esté dentro de los límites del tablero,
 * y que el tipo de ficha sea válido.
 *
 * @param row la fila donde se añadirá la ficha
 * @param column la columna donde se añadirá la ficha
 * @param type el tipo de ficha, debe ser uno de los siguientes: "Freelance", "Rough", "Fixed", "Flying", "Invisible"
 */
public void addTile(String type, int row, int column) {
    if (!isValidType(type)) {
        throw new IllegalArgumentException("Tipo de ficha inválido.");
    }
    if (row < 0 || row >= h || column < 0 || column >= w) {
        throw new IllegalArgumentException("Coordenadas fuera de los límites del tablero.");
    }
    if (starting[row][column] != null) {
        throw new IllegalArgumentException("Posición ya ocupada.");
    }
    char tileChar = ' '; 
    String color = "black"; 
    
    if (type.equals("Freelance")) {
        tileChar = 't';
        color = PuzzleBoardInitializer.getColorForTile(tileChar);
    } else if (type.equals("Rough")) {
        tileChar = 'e';
        color = PuzzleBoardInitializer.getColorForTile(tileChar);
    } else if (type.equals("Fixed")) {
        tileChar = 'z';
        color = PuzzleBoardInitializer.getColorForTile(tileChar);
    } else if (type.equals("Flying")) {
        tileChar = 's';
        color = PuzzleBoardInitializer.getColorForTile(tileChar);
    } else if (type.equals("Invisible")) {
        tileChar = 'b'; 
    }

    Tile tile = new Tile(type, 50, 50, column * 50, row * 50, color, tileChar);
    if (!type.equals("Invisible")) {
        tile.makeVisible();
    }
    starting[row][column] = tile;
}

    
    /**
     * Elimina una ficha en la posición especificada del tablero inicial.
     * Verifica que la posición esté dentro de los límites y que haya una ficha en esa posición.
     *
     * @param row la fila de la ficha a eliminar
     * @param column la columna de la ficha a eliminar
     */
    public void deleteTile(int row, int column) {
    if (row >= 0 && row < h && column >= 0 && column < w) {
        if (starting[row][column] != null) {
            if(starting[row][column].getTypet().equals("Fixed")){
                throw new IllegalArgumentException("La ficha es de tipo Fixed y no puede ser eliminada");
            }
            starting[row][column].makeInvisible(); 
            starting[row][column] = null; 
        } else {
            throw new IllegalArgumentException("No hay ficha en la posición indicada.");
        }
    } else {
        throw new IllegalArgumentException("Coordenadas fuera de los límites del tablero.");
    }
}
    
    /**
     * Añade pegamento a la ficha en la posición especificada.
     * Verifica que la posición esté dentro de los límites y añade pegamento a las fichas adyacentes.
     *
     * @param row la fila de la ficha a pegar
     * @param col la columna de la ficha a pegar
     */
   public void addGlue(int row, int col) {
    if (row < 0 || row >= starting.length || col < 0 || col >= starting[0].length) {
        throw new IllegalArgumentException("La posición no es parte del tablero");
    }

    Tile tile = starting[row][col]; 
    for (ArrayList<Tile> group : glue) {
        if (group.contains(tile)) {
            throw new IllegalArgumentException("Esa ficha ya está pegada");
        }
    }
    ArrayList<Tile> adjacentTiles = getAdjacentTiles(row, col);
    Glue.addGlue(tile, adjacentTiles);
}
    
    /**
     * Elimina el pegamento de la ficha en la posición especificada.
     * Verifica que la posición esté dentro de los límites y elimina el pegamento de las fichas adyacentes.
     *
     * @param row la fila de la ficha a deshacer el pegado
     * @param col la columna de la ficha a deshacer el pegado
     */
    public void deleteGlue(int row, int col) {
        Tile tile = starting[row][col]; 
        ArrayList<Tile> adjacentTiles = getAdjacentTiles(row, col);
        
        for (Tile adjacentTile : adjacentTiles) {
            Glue.deleteGlue(tile, adjacentTiles); 
        }
    }
    
    /**
     * Obtiene las fichas adyacentes a la posición especificada.
     * Devuelve una lista de fichas que están adyacentes y visibles.
     *
     * @param row la fila de la ficha
     * @param column la columna de la ficha
     * @return una lista de fichas adyacentes
     */
    private ArrayList<Tile> getAdjacentTiles(int row, int column) {
        ArrayList<Tile> adjacentTiles = new ArrayList<>();
        if (row > 0 && starting[row - 1][column] != null) { 
            adjacentTiles.add(starting[row - 1][column]);
        }
        if (row < starting.length - 1 && starting[row + 1][column] != null) {
            adjacentTiles.add(starting[row + 1][column]);
        }
        if (column > 0 && starting[row][column - 1] != null) { 
            adjacentTiles.add(starting[row][column - 1]);
        }
        if (column < starting[0].length - 1 && starting[row][column + 1] != null) { 
            adjacentTiles.add(starting[row][column + 1]);
        }
        return adjacentTiles;
    }
    
       /**
     * Crea un hueco en la posición especificada del tablero inicial.
     * Verifica que la posición esté dentro de los límites y que no haya ya un hueco.
     *
     * @param row la fila donde se creará el hueco
     * @param column la columna donde se creará el hueco
     */
    public void makeHole(int row, int column) {
    if (row >= 0 && row < h && column >= 0 && column < w) {
        Tile existingTile = starting[row][column];
        if (existingTile != null && "hole".equals(existingTile.getTypet())) {
            throw new IllegalArgumentException("Ya hay un hueco en esta posición.");
        }

        String color = "white"; 
        Hole holeTile = new Hole(50, 50, column * 50, row * 50);
        holeTile.makeVisible(); 
        starting[row][column] = holeTile; 
    } else {
        throw new IllegalArgumentException("Coordenadas fuera de los límites del tablero.");
    }
}
    
    /**
     * Reubica una ficha de la posición de origen a la posición de destino.
     * Verifica que ambas posiciones estén dentro de los límites y que haya una ficha en la posición de origen.
     *
     * @param from arreglo que contiene la posición de origen [fila, columna]
     * @param to arreglo que contiene la posición de destino [fila, columna]
     */
public void relocate(int[] from, int[] to) {
    int fromRow = from[0];
    int fromColumn = from[1];
    int toRow = to[0];
    int toColumn = to[1];

    if (fromRow >= 0 && fromRow < h && fromColumn >= 0 && fromColumn < w &&
        toRow >= 0 && toRow < h && toColumn >= 0 && toColumn < w) {
        if (starting[fromRow][fromColumn] == null) {
            throw new IllegalArgumentException("No hay ficha en la posición de origen.");
        }
        if (starting[fromRow][fromColumn].getTypet().equals("Fixed")) {
            throw new IllegalArgumentException("La ficha es de tipo Fixed y no puede ser reubicada");
        }
        if (starting[fromRow][fromColumn].getTypet().equals("hole")) {
            return;
        }

        Tile tile = starting[fromRow][fromColumn];

        if (starting[toRow][toColumn] == null) {
            starting[toRow][toColumn] = tile;
            starting[fromRow][fromColumn] = null;
            tile.relocate(toColumn * 50, toRow * 50); 
        } else if (starting[toRow][toColumn].getTypet().equals("hole")) {
            deleteTile(fromRow, fromColumn);
        } else {
            throw new IllegalArgumentException("La posición de destino está ocupada.");
        }
    } else {
        throw new IllegalArgumentException("Coordenadas fuera de los límites del tablero.");
    }
}
    
    /**
     * Intercambia las fichas entre los tableros inicial y final.
     * Mueve cada ficha del tablero final al inicial y viceversa.
     */
    public void exchange() {
        int spacing = 50; 
        int finalOffsetX = w * 50 + spacing;  
    
        Tile[][] tempStarting = new Tile[h][w]; 
    
        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {
                tempStarting[row][column] = starting[row][column];
    
                if (starting[row][column] != null) {
                    starting[row][column].setPosition(column * 50 + finalOffsetX, row * 50);
                }
                if (ending[row][column] != null) {
                    ending[row][column].setPosition(column * 50, row * 50);
                }
    
                starting[row][column] = ending[row][column];
                ending[row][column] = tempStarting[row][column];
            }
        }
        makeVisible();
    }
    
    /**
     * Realiza un "tilt" inteligente usando la función misPlacedTiles().
     * Determina la dirección que minimiza la cantidad de fichas fuera de lugar.
     */
    public void tilt() {
    Simulator simulator = new Simulator(this);
    Tile[][] copy = gameCopy();
    
    // Calcular el número actual de fichas fuera de lugar
    int currentMisplaced = misPlacedTiles(copy);
    
    // Simular tilt a la izquierda
    simulator.tiltSimulator('l', copy, this);
    int leftDiff = misPlacedTiles(copy);
    copy = gameCopy();
    
    // Simular tilt a la derecha
    simulator.tiltSimulator('r', copy, this);
    int rightDiff = misPlacedTiles(copy);
    copy = gameCopy();
    
    // Simular tilt hacia arriba
    simulator.tiltSimulator('u', copy, this);
    int upDiff = misPlacedTiles(copy);
    copy = gameCopy();
    
    // Simular tilt hacia abajo
    simulator.tiltSimulator('d', copy, this);
    int downDiff = misPlacedTiles(copy);
    
    // Encontrar la dirección con la menor cantidad de fichas fuera de lugar
    int minDiff = Math.min(Math.min(leftDiff, rightDiff), Math.min(upDiff, downDiff));
    
    // Realizar el tilt solo si mejora la situación
    if (minDiff < currentMisplaced) {
        if (minDiff == leftDiff) {
            tilt('l');
        } else if (minDiff == rightDiff) {
            tilt('r');
        } else if (minDiff == upDiff) {
            tilt('u');
        } else if (minDiff == downDiff) {
            tilt('d');
        }
    }
}

    /**
     * Realiza una inclinación en la dirección especificada.
     * Llama a la función de inclinación correspondiente según la dirección.
     *
     * @param direction la dirección en la que se realizará la inclinación ('l', 'r', 'u', 'd')
     */
    public void tilt(char direction) {
        switch (direction) {
            case 'l':
                tiltLeft();
                break;
            case 'r':
                tiltRight();
                break;
            case 'u':
                tiltUp();
                break;
            case 'd':
                tiltDown();
                break;
            default:
                JOptionPane.showMessageDialog(null,"Dirección inválida");
        }
    }
    
       


/**
 * Realiza la inclinación hacia la izquierda en el tablero.
 * Mueve las fichas a la izquierda y elimina las que caen en un hueco.
 */
private void tiltLeft() {
    for (int row = 0; row < h; row++) {
        boolean moved;
        do {
            moved = false;
            for (int column = 1; column < w; column++) {
                if (starting[row][column] != null) {
                    if (starting[row][column].getTypet().equals("Fixed") || starting[row][column].getTypet().equals("Rough") || starting[row][column].getTypet().equals("hole")) {
                        continue;
                    }

                    if (starting[row][column - 1] == null || (isHoleAt(row, column - 1) && starting[row][column].getTypet().equals("Flying"))) {
                        if (isHoleAt(row, column - 1)) {
                            holesToRestore.add(new int[]{row, column - 1});
                            deleteTile(row, column - 1);
                        }
                        relocate(new int[]{row, column}, new int[]{row, column - 1});
                        moved = true;
                        restoreHoles();
                    } else if (isHoleAt(row, column - 1)) {
                        deleteTile(row, column);
                        break;
                    }
                }
            }
            moved = moved || canMoveLeft(row);
        } while (moved);
    }
    restoreHoles();
}

/**
 * Realiza la inclinación hacia la derecha en el tablero.
 * Mueve las fichas a la derecha y elimina las que caen en un hueco.
 */
private void tiltRight() {
    for (int row = 0; row < h; row++) {
        boolean moved;
        do {
            moved = false;
            for (int column = w - 2; column >= 0; column--) {
                if (starting[row][column] != null) {
                    if (starting[row][column].getTypet().equals("Fixed") || starting[row][column].getTypet().equals("Rough") || starting[row][column].getTypet().equals("hole")) {
                        continue; 
                    }

                    if (starting[row][column + 1] == null || (isHoleAt(row, column + 1) && starting[row][column].getTypet().equals("Flying"))) {
                        if (isHoleAt(row, column + 1)) {
                            holesToRestore.add(new int[]{row, column + 1});
                            deleteTile(row, column + 1);
                        }
                        relocate(new int[]{row, column}, new int[]{row, column + 1});
                        moved = true;
                        restoreHoles();
                    } else if (isHoleAt(row, column + 1)) {
                        deleteTile(row, column);
                        break;
                    }
                }
            }
            moved = moved || canMoveRight(row);
        } while (moved);
    }
    restoreHoles();
}

/**
 * Realiza la inclinación hacia arriba en el tablero.
 * Mueve las fichas hacia arriba y elimina las que caen en un hueco.
 */
private void tiltUp() {
    for (int column = 0; column < w; column++) {
        boolean moved;
        do {
            moved = false;
            for (int row = 1; row < h; row++) {
                if (starting[row][column] != null) {
                    if (starting[row][column].getTypet().equals("Fixed") || starting[row][column].getTypet().equals("Rough") || starting[row][column].getTypet().equals("hole")) {
                        continue;  
                    }

                    if (starting[row - 1][column] == null || (isHoleAt(row - 1, column) && starting[row][column].getTypet().equals("Flying"))) {
                        if (isHoleAt(row - 1, column)) {
                            holesToRestore.add(new int[]{row - 1, column});
                            deleteTile(row - 1, column);
                        }
                        relocate(new int[]{row, column}, new int[]{row - 1, column});
                        moved = true;
                        restoreHoles();
                    } else if (isHoleAt(row - 1, column)) {
                        deleteTile(row, column);
                        break;
                    }
                }
            }
            moved = moved || canMoveUp(column);
        } while (moved);
    }
    restoreHoles();
}

/**
 * Realiza la inclinación hacia abajo en el tablero.
 * Mueve las fichas hacia abajo y elimina las que caen en un hueco.
 */
private void tiltDown() {
    for (int column = 0; column < w; column++) {
        boolean moved;
        do {
            moved = false;
            for (int row = h - 2; row >= 0; row--) {
                if (starting[row][column] != null) {
                    if (starting[row][column].getTypet().equals("Fixed") || starting[row][column].getTypet().equals("Rough") || starting[row][column].getTypet().equals("hole")) {
                        continue;  
                    }

                    if (starting[row + 1][column] == null || (isHoleAt(row + 1, column) && starting[row][column].getTypet().equals("Flying"))) {
                        if (isHoleAt(row + 1, column)) {
                            holesToRestore.add(new int[]{row + 1, column});
                            deleteTile(row + 1, column);
                        }
                        relocate(new int[]{row, column}, new int[]{row + 1, column});
                        moved = true;
                        restoreHoles();
                    } else if (isHoleAt(row + 1, column)) {
                        deleteTile(row, column);
                        break;
                    }
                }
            }
            moved = moved || canMoveDown(column);
        } while (moved);
    }
    restoreHoles();
}

/**
 * Método para restaurar los huecos en las posiciones originales después de un tilt.
 */
private void restoreHoles() {
    Iterator<int[]> iterator = holesToRestore.iterator();
    while (iterator.hasNext()) {
        int[] position = iterator.next();
        int r = position[0];
        int c = position[1];
        
        if (starting[r][c] == null || !starting[r][c].getTypet().equals("Flying")) {
            makeHole(r, c);
            iterator.remove(); // Elimina esta posición de la lista de restauración
        }
    }
}
    
        /**
     * Mueve el grupo de fichas pegadas.
     *
     * @param tile la ficha que pertenece al grupo de pegamento
     * @param dx desplazamiento en la dirección x
     * @param dy desplazamiento en la dirección y
     */
    private void moveGlue(Tile tile, int dx, int dy) {
        ArrayList<Tile> glueGroup = getGlue(tile);
        if (glueGroup != null) {
            int minMoves = Integer.MAX_VALUE;
            for (Tile t : glueGroup) {
                int row = t.getRow();
                int column = t.getColumn();
                int moves = 0;
                while (isValidMove(row + (moves + 1) * dy, column + (moves + 1) * dx)) {
                    moves++;
                }
                if (isHoleAt(row + (moves + 1) * dy, column + (moves + 1) * dx)) {
                    moves++;
                }
                minMoves = Math.min(minMoves, moves);
            }
            if (minMoves > 0) {
                for (Tile t : glueGroup) {
                    int row = t.getRow();
                    int column = t.getColumn();
                    relocate(new int[]{row, column}, new int[]{row + minMoves * dy, column + minMoves * dx});
                    incrementMoveCount(row, column);
                }
            }
        }
    }
    
      /**
     * Verifica si el movimiento es válido.
     *
     * @param row la fila de destino
     * @param column la columna de destino
     * @return true si el movimiento es válido, false en caso contrario
     */
    private boolean isValidMove(int row, int column) {
        return row >= 0 && row < h && column >= 0 && column < w && starting[row][column] == null;
    }
    
      /**
     * Incrementa el contador de movimientos para la ficha en la posición especificada.
     *
     * @param row la fila de la ficha
     * @param column la columna de la ficha
     */
    private void incrementMoveCount(int row, int column) {
        String key = row + "," + column;
        moveCountMap.put(key, moveCountMap.getOrDefault(key, 0) + 1);
    }
    
      /**
     * Obtiene el mapa de contadores de movimientos.
     *
     * @return el mapa de contadores de movimientos
     */
    private Map<String, Integer> getMoveCountMap() {
        return moveCountMap;
    }
    /**
     * Verifica si hay fichas que pueden moverse a la izquierda en la fila especificada.
     *
     * @param row la fila que se está evaluando
     * @return true si hay fichas que pueden moverse, false en caso contrario
     */
    private boolean canMoveLeft(int row) {
    for (int column = 1; column < w; column++) {
        if (starting[row][column] != null && !starting[row][column].getTypet().equals("Fixed") && !starting[row][column].getTypet().equals("hole") &&  !starting[row][column].getTypet().equals("Rough") && starting[row][column - 1] == null) {
            return true; 
        }
    }
    return false;
}

/**
     * Verifica si hay fichas que pueden moverse a la derecha en la fila especificada.
     *
     * @param row la fila que se está evaluando
     * @return true si hay fichas que pueden moverse, false en caso contrario
     */
private boolean canMoveRight(int row) {
    for (int column = w - 2; column >= 0; column--) {
        if (starting[row][column] != null && !starting[row][column].getTypet().equals("Fixed") && !starting[row][column].getTypet().equals("hole") &&  !starting[row][column].getTypet().equals("Rough") && starting[row][column + 1] == null) {
            return true; 
        }
    }
    return false;
}

/**
     * Verifica si hay fichas que pueden moverse hacia arriba en la columna especificada.
     *
     * @param row la fila que se está evaluando
     * @return true si hay fichas que pueden moverse, false en caso contrario
     */
private boolean canMoveUp(int column) {
    for (int row = 1; row < h; row++) {
        if (starting[row][column] != null && !starting[row][column].getTypet().equals("hole") && !starting[row][column].getTypet().equals("Fixed") && !starting[row][column].getTypet().equals("Rough") && starting[row - 1][column] == null) {
            return true; 
        }
    }
    return false;
}

/**
     * Verifica si hay fichas que pueden moverse hacia abajo en la columna especificada.
     *
     * @param row la fila que se está evaluando
     * @return true si hay fichas que pueden moverse, false en caso contrario
     */
private boolean canMoveDown(int column) {
    for (int row = h - 2; row >= 0; row--) {
        if (starting[row][column] != null && !starting[row][column].getTypet().equals("Fixed") && !starting[row][column].getTypet().equals("hole") &&  !starting[row][column].getTypet().equals("Rough") && starting[row + 1][column] == null) {
            return true; 
        }
    }
    return false;
}
    
    /**
     * Verifica si hay un hueco en la posición especificada.
     *
     * @param row la fila de la posición
     * @param column la columna de la posición
     * @return true si hay un hueco, false en caso contrario
     */
    private boolean isHoleAt(int row, int column) {
        return row >= 0 && row < h && column >= 0 && column < w && starting[row][column] != null && "hole".equals(starting[row][column].getTypet());
    }
    
    /**
     * Cuenta el número de fichas mal colocadas en el tablero.
     *
     * @return el número de fichas mal colocadas
     */
  public int misPlacedTiles() {
    int misPlacedCount = 0;

    for (int row = 0; row < h; row++) {
        for (int column = 0; column < w; column++) {
           
            if (ending[row][column] != null) {
                if (starting[row][column] == null || !starting[row][column].getColor().equals(ending[row][column].getColor())) {
                    misPlacedCount++;
                }
            }
           
            if (starting[row][column] != null) {
                if (ending[row][column] == null || !ending[row][column].getColor().equals(starting[row][column].getColor())) {
                    misPlacedCount++;
                }
            }
        }
    }

    return misPlacedCount;
}
    
    /**
     * Cuenta el número de fichas mal colocadas en una copia del tablero.
     *
     * @param startingCopy la copia del tablero inicial
     * @return el número de fichas mal colocadas
     */
    private int misPlacedTiles(Tile[][] startingCopy) {
        int misPlacedCount = 0;
    
        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {     
                if ((startingCopy[row][column] != null && ending[row][column] == null) || 
                    (ending[row][column] != null && startingCopy[row][column] == null) ||
                    (startingCopy[row][column] != null && !startingCopy[row][column].getColor().equals(ending[row][column].getColor()))) {
                    misPlacedCount++;
                }
            }
        }
    
        return misPlacedCount;
    }
        
            
    /**
     * Obtiene una lista de fichas fijas que no se pueden mover.
     *
     * @return una lista de coordenadas de las fichas fijas
     */
    public int[][] fixedTiles() {
        Tile[][] originalCopy = gameCopy();     
        Tile[][] upCopy = gameCopy();
        Tile[][] downCopy = gameCopy();
        Tile[][] leftCopy = gameCopy();
        Tile[][] rightCopy = gameCopy();
        
        Simulator simulatorU = new Simulator(this);
        simulatorU.tiltSimulator('u', upCopy, this);
       
        Simulator simulatorD = new Simulator(this);
        simulatorD.tiltSimulator('d', downCopy, this);
      
        Simulator simulatorL = new Simulator(this);
        simulatorL.tiltSimulator('l', leftCopy, this);
        
        Simulator simulatorR = new Simulator(this);
        simulatorR.tiltSimulator('r', rightCopy, this);
        ArrayList<int[]> fixed = new ArrayList<>();
  
        for (int row = 0; row < originalCopy.length; row++) {
            for (int column = 0; column < originalCopy[0].length; column++) {
                Tile originalTile = originalCopy[row][column];
                
             
                if (originalTile != null &&
                    originalTile.equals(upCopy[row][column]) &&
                    originalTile.equals(downCopy[row][column]) &&
                    originalTile.equals(leftCopy[row][column]) &&
                    originalTile.equals(rightCopy[row][column])) {
                    
                 
                    fixed.add(new int[]{row, column});
                   
                } else {
                
                }
            }
        }
        int[][] array = new int[fixed.size()][2];
        for (int i = 0; i < fixed.size(); i++) {
            array[i] = fixed.get(i);
        }
        return array;
    }
    
    
    /**
     * Verifica si el tablero actual es el objetivo deseado.
     *
     * @return true si el tablero actual coincide con el objetivo, false en caso contrario
     */
    public boolean isGoal() {
        if(starting == ending){
            
            return true;
        }
        return false; 
    }
    /**
     * Verifica si ambos tableros son iguales
     * retorna true si lo son, false si no
     */
    public boolean ok() {
    for (int i = 0; i < starting.length; i++) {
        for (int j = 0; j < starting[i].length; j++) {
            if (starting[i][j] != null && ending[i][j] != null) {
                if (!starting[i][j].equals(ending[i][j])) {
                    return false;
                }
            } else if (starting[i][j] != ending[i][j]) {
                return false;
            }
        }
    }
    return true;
}
    
    
    /**
     * Finaliza la máquina virtual y cierra el programa.
     */
    public void finish() {
        System.exit(0);
    }
    
    /**
     * Devuelve la disposición actual de las fichas.
     *
     * @return el tablero actual
     */
    public Tile[][] actualArrangement() {
        return starting; 
    }
    /**
     * Devuelve la disposición final de las fichas.
     *
     * @return el tablero final actual
     */
    public Tile[][] actualEnding() {
        return ending; 
    }
    
    /**
     * Hace visibles todas las fichas del tablero inicial y final.
     */
    public void makeVisible() {
        PuzzleBoardInitializer.makeVisible();
        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {
                if (starting[row][column] != null) {
                    starting[row][column].makeVisible();
                }
            }
        }
        
        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {
                if (ending[row][column] != null) {
                    ending[row][column].makeVisible();
                }
            }
        }
        isVisible = true;
    }
    
    /**
     * Hace invisibles todas las fichas del tablero inicial y final.
     */
    public void makeInvisible() {
        PuzzleBoardInitializer.makeInvisible();
        for (int row = 0; row < h; row++) { 
            for (int column = 0; column < w; column++) {
                if (starting[row][column] != null) {
                    starting[row][column].makeInvisible(); 
                }
            }
        }
    
        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {
                if (ending[row][column] != null) {
                    ending[row][column].makeInvisible();
                }
            }
        }
        isVisible = false;
    }
    
    /**
     * Crea una copia del tablero actual.
     *
     * @return una copia del tablero
     * */
     
    private Tile[][] gameCopy() {
        Tile[][] copy = new Tile[starting.length][starting[0].length];
        for (int h = 0; h < starting.length; h++) {
            for (int w = 0; w < starting[0].length; w++) {
                if (starting[h][w] != null) {
                    copy[h][w] = new Tile(
                        starting[h][w].getWidth(), 
                        starting[h][w].getHeight(), 
                        starting[h][w].getXPosition(), 
                        starting[h][w].getYPosition(), 
                        starting[h][w].getColor(), 
                        starting[h][w].getType()    
                    );
                }
            }
        }
        return copy;
    }
    
    public int getHeight() {
        return h;
    }

    public int getWeight() {
        return w;
    }

    public Tile[][] getStarting() {
        return starting;
    }

    public Tile[][] getEnding() {
        return ending;
    }
    public boolean isVisible(Tile tile){
        return tile.visible;
    }
    ArrayList<Tile> getGlue(Tile tile){
        return Glue.getGlueGroup(tile);
    }
    
    
       /**
     * Verifica si la ficha en la posición especificada está pegada.
     *
     * @param row la fila de la ficha
     * @param column la columna de la ficha
     * @return true si la ficha está pegada, false en caso contrario
     */
    private boolean isGlued(Tile tile) {
        return Glue.isGlued(tile);
    }
    /**
     * Verifica si el tipo de ficha es válido.
     *
     * @param type el tipo de ficha a verificar
     * @return true si el tipo es válido, false en caso contrario
     */
    private boolean isValidType(String type) {
        return type.equals("Freelance") || type.equals("Rough") || type.equals("Fixed") || type.equals("Flying") || type.equals("Invisible");
    }
    
 public boolean isSolvable() {
        Queue<State> queue = new LinkedList<>();
        queue.add(new State(tablero_inicial));

        while (!queue.isEmpty()) {
            State current = queue.poll();

            if (isGoalState(current.board)) {
                return true;
            }

            // Simulación de movimientos en todas las direcciones
            for (char direction : new char[]{'u', 'd', 'l', 'r'}) {
                char[][] tiltedBoard = tiltCopy(current.board, direction);
                if (!isSameBoard(current.board, tiltedBoard)) {
                    queue.add(new State(tiltedBoard));
                }
            }
        }
        return false;
    }

    private boolean isGoalState(char[][] board) {
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                if (board[i][j] != tablero_final[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    private char[][] tiltCopy(char[][] board, char direction) {
        char[][] copy = new char[h][w];
        for (int i = 0; i < h; i++) {
            System.arraycopy(board[i], 0, copy[i], 0, w);
        }
        tilt(copy, direction);
        return copy;
    }

    private void tilt(char[][] board, char direction) {
        switch (direction) {
            case 'u' -> tiltUp(board);
            case 'd' -> tiltDown(board);
            case 'l' -> tiltLeft(board);
            case 'r' -> tiltRight(board);
        }
    }

    private void tiltUp(char[][] board) {
        for (int col = 0; col < w; col++) {
            int target = 0;
            for (int row = 0; row < h; row++) {
                if (board[row][col] != '.') {
                    board[target][col] = board[row][col];
                    if (target != row) board[row][col] = '.';
                    target++;
                }
            }
        }
    }

    private void tiltDown(char[][] board) {
        for (int col = 0; col < w; col++) {
            int target = h - 1;
            for (int row = h - 1; row >= 0; row--) {
                if (board[row][col] != '.') {
                    board[target][col] = board[row][col];
                    if (target != row) board[row][col] = '.';
                    target--;
                }
            }
        }
    }

    private void tiltLeft(char[][] board) {
        for (int row = 0; row < h; row++) {
            int target = 0;
            for (int col = 0; col < w; col++) {
                if (board[row][col] != '.') {
                    board[row][target] = board[row][col];
                    if (target != col) board[row][col] = '.';
                    target++;
                }
            }
        }
    }

    private void tiltRight(char[][] board) {
        for (int row = 0; row < h; row++) {
            int target = w - 1;
            for (int col = w - 1; col >= 0; col--) {
                if (board[row][col] != '.') {
                    board[row][target] = board[row][col];
                    if (target != col) board[row][col] = '.';
                    target--;
                }
            }
        }
    }

    private boolean isSameBoard(char[][] board1, char[][] board2) {
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                if (board1[i][j] != board2[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    private static class State {
        char[][] board;

        State(char[][] board) {
            this.board = new char[board.length][];
            for (int i = 0; i < board.length; i++) {
                this.board[i] = board[i].clone();
            }
        }
    }
    // Método para resolver el puzzle usando BFS y devolver los movimientos necesarios
    public void solvePuzzle() {
        Queue<Tile[][]> queue = new LinkedList<>();
        Queue<List<String>> moves = new LinkedList<>();
        Set<String> visited = new HashSet<>();

        queue.add(starting);  // Añadir el estado inicial
        moves.add(new ArrayList<>());
        visited.add(boardToString(starting));

        while (!queue.isEmpty()) {
            Tile[][] currentBoard = queue.poll();
            List<String> currentMoves = moves.poll();

            // Verificar si hemos alcanzado el estado final
            if (isGoalState(currentBoard)) {
                System.out.println("Puzzle Resuelto:");
                for (String move : currentMoves) {
                    applyMove(starting, move.charAt(move.length() - 1));
                    renderBoard();  // Actualizar visualmente el tablero

                    try {
                        Thread.sleep(500); // Retardo para visualizar cambios
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                }
                return;
            }

            // Intentar cada dirección de movimiento
            for (char direction : new char[]{'l', 'r', 'u', 'd'}) {
                Tile[][] nextBoard = tiltCopy(currentBoard, direction);
                String boardString = boardToString(nextBoard);

                if (!visited.contains(boardString)) {
                    queue.add(nextBoard);
                    visited.add(boardString);

                    List<String> newMoves = new ArrayList<>(currentMoves);
                    newMoves.add("Move " + direction);
                    moves.add(newMoves);
                }
            }
        }
        System.out.println("El puzzle no tiene solución.");
    }

    // Método auxiliar para verificar si un estado coincide con el estado final
    private boolean isGoalState(Tile[][] state) {
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                if (state[i][j] != null && ending[i][j] != null) {
                    if (!state[i][j].getTypet().equals(ending[i][j].getTypet())) {
                        return false;
                    }
                } else if (state[i][j] != ending[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    // Copia el tablero actual
    private Tile[][] tiltCopy(Tile[][] board, char direction) {
        Tile[][] copiedBoard = gameCopy();
        switch (direction) {
            case 'l':
                tiltLeft();
                break;
            case 'r':
                tiltRight();
                break;
            case 'u':
                tiltUp();
                break;
            case 'd':
                tiltDown();
                break;
        }
        return copiedBoard;
    }

    private String boardToString(Tile[][] board) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                sb.append(board[i][j] == null ? "." : board[i][j].getTypet().charAt(0));
            }
        }
        return sb.toString();
    }

    private void applyMove(Tile[][] board, char direction) {
        switch (direction) {
            case 'l':
                tiltLeft();
                break;
            case 'r':
                tiltRight();
                break;
            case 'u':
                tiltUp();
                break;
            case 'd':
                tiltDown();
                break;
            default:
                throw new IllegalArgumentException("Dirección no válida: " + direction);
        }
    }

    private void renderBoard() {
        printBoard(starting);
    }

    private void printBoard(Tile[][] board) {
        for (int i = 0; i < h; i++) {
            for (int j = 0; j < w; j++) {
                System.out.print((board[i][j] == null ? "." : board[i][j].getTypet().charAt(0)) + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
    
}
