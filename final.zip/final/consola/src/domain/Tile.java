package domain;
import java.util.Objects;
import shapes.Circle;

/**
 * Clase que representa una ficha en el juego.
 */
public class Tile {
    private shapes.Rectangle rectangle;  
    private shapes.Rectangle glueRectangle;
    private char type;          
    private String typet;        
    private boolean glued;
    public boolean visible;
    private shapes.Circle freelanceCircle;
    private Circle tinyCircle;
    

    /**
     * Constructor para crear una ficha.
     *
     * @param width       Ancho de la ficha.
     * @param height      Altura de la ficha.
     * @param xPosition   Posición en el eje X.
     * @param yPosition   Posición en el eje Y.
     * @param color       Color de la ficha.
     * @param type        Tipo de ficha.
     */
    public Tile(int width, int height, int xPosition, int yPosition, String color, char type) {
        this.rectangle = new shapes.Rectangle(width, height, xPosition, yPosition, color);
        this.type = type;
        this.typet = "ficha"; 
        this.glued = false;
        this.visible = true;
    }

    /**
     * Constructor para crear una ficha.
     *
     * @param width       Ancho de la ficha.
     * @param height      Altura de la ficha.
     * @param xPosition   Posición en el eje X.
     * @param yPosition   Posición en el eje Y.
     * @param color       Color de la ficha.
     * @param type        Tipo de ficha.
     */
    public Tile(String typet, int width, int height, int xPosition, int yPosition, String color, char type) {
        this.rectangle = new shapes.Rectangle(width, height, xPosition, yPosition, color);
        this.type = type;
        this.typet = typet;
        this.glued = false;
        this.visible = true;
    }


  
    public void relocate(int newX, int newY) {
   
    rectangle.setX(newX);
    rectangle.setY(newY);

   
    if (freelanceCircle != null) {
        freelanceCircle.setPosition(newX + 20, newY + 20); 
    }


    if (glued && glueRectangle != null) {
        glueRectangle.setX(newX + 20); 
        glueRectangle.setY(newY + 20);  
    }
}

public void setFreelance(boolean isFreelance) {
    if (isFreelance) {
        if (freelanceCircle == null) {
            freelanceCircle = new Circle(10, this.getXPosition() + 20, this.getYPosition() + 20, "blue", true);
            freelanceCircle.makeVisible(); 
        }
    } else {
        if (freelanceCircle != null) {
            freelanceCircle.makeInvisible(); 
            freelanceCircle = null; 
        }
    }
}

    public String getTypet() {
        return typet;
    }
    
    public void setGlued(boolean glued) {
        this.glued = glued;
        if (glued) {
          
            if (glueRectangle == null) {
                glueRectangle = new shapes.Rectangle(10, 10, this.getXPosition() + 20, this.getYPosition() + 20, "black");
                glueRectangle.makeVisible();
            }
        } else {
            if (glueRectangle != null) {
                glueRectangle.makeInvisible(); 
                glueRectangle = null;
            }
        }
    }

    public boolean isGlued() {
        return glued;
    }


    /**
     * Obtiene el color de la ficha.
     *
     * @return color de la ficha.
     */
    public String getColor() {
        return rectangle.getColor(); 
    }

    /**
     * Obtiene el ancho de la ficha.
     *
     * @return ancho de la ficha.
     */
    public int getWidth(){
        return rectangle.getWidth();
    } 

    /**
     * Obtiene la altura de la ficha.
     *
     * @return altura de la ficha.
     */
    public int getHeight() {
        return rectangle.getHeight();
    }

    /**
     * Establece la posición de la ficha.
     *
     * @param x nueva posición en el eje X.
     * @param y nueva posición en el eje Y.
     */
    public void setPosition(int x, int y) {
        this.rectangle.setX(x);
        this.rectangle.setY(y);
    }

    /**
     * Hace visible la ficha.
     */
    public void makeVisible() {
        rectangle.makeVisible();
        visible = true;
    }

    /**
     * Hace invisible la ficha.
     */
    public void makeInvisible() {
        rectangle.makeInvisible();
        visible = false;
    }

    /**
     * Cambia el color de la ficha.
     *
     * @param newColor nuevo color para la ficha.
     */
    public void changeColor(String newColor) {
        rectangle.changeColor(newColor);
    }

    /**
     * Obtiene la posición en el eje X de la ficha.
     *
     * @return posición en el eje X.
     */
    public int getXPosition() {
        return rectangle.getXPosition();
    }

    /**
     * Obtiene la posición en el eje Y de la ficha.
     *
     * @return posición en el eje Y.
     */
    public int getYPosition() {
        return rectangle.getYPosition();
    }

    /**
     * Obtiene el tipo de ficha.
     *
     * @return tipo de ficha.
     */
    public char getType() {
        return type;
    }
    
    /**
     * Establece el tipo de ficha.
     *
     * @param type nuevo tipo de ficha.
     */
    public void setTypet(String typet) {
        this.typet = typet;
    }
    /**
     * Verifica si la ficha es visible.
     *
     * @return true si la ficha es visible, false en caso contrario.
     */
    public boolean isVisible(Tile tile) {
        return this.visible;
    }

    /**
     * Obtiene la fila en la que se encuentra la ficha.
     *
     * @return fila de la ficha.
     */
    public int getRow() {
        return getYPosition() / 50; 
    }
    
    /**
     * Obtiene la columna en la que se encuentra la ficha.
     *
     * @return columna de la ficha.
     */
    public int getColumn() {
        return getXPosition() / 50;
    }
    @Override
public boolean equals(Object obj) {
    if (this == obj) {
        return true;
    }
    if (obj == null || getClass() != obj.getClass()) {
        return false;
    }
    Tile tile = (Tile) obj;
    return rectangle.equals(tile.rectangle) &&
           type == tile.type &&
           typet.equals(tile.typet) &&
           glued == tile.glued &&
           visible == tile.visible;
}

@Override
public int hashCode() {
    return Objects.hash(rectangle, type, typet, glued, visible);
}
    
    
}
