package domain;

import java.util.HashMap;
import java.util.Map;


public class PuzzleBoardInitializer {
    
    private static final int TILE_SIZE = 50;
    private static shapes.Rectangle board;
    private static shapes.Rectangle endBoard;

    /**
     * Inicializa un tablero en el arreglo `starting` y muestra el rectángulo en la interfaz.
     */
    public static void initializeStartingBoard(Tile[][] starting, int h, int w) {
        board = new shapes.Rectangle(h * TILE_SIZE, w * TILE_SIZE, 0, 0, "black");
        board.makeVisible();
        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {
                starting[row][column] = null; 
            }
        }
    }

    /**
     * Inicializa el tablero `ending` con el rectángulo visible en una posición desplazada.
     */
    public static void initializeEndingBoard(Tile[][] ending, int h, int w) {
        int spacing = TILE_SIZE;  
        int finalOffsetX = w * TILE_SIZE + spacing; 
        endBoard = new shapes.Rectangle(h * TILE_SIZE, w * TILE_SIZE, finalOffsetX, 0, "black");
        endBoard.makeVisible();
        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {
                ending[row][column] = null;
            }
        }
    }

    /**
     * Convierte un tablero de caracteres a objetos Tile para el tablero inicial.
     */
    public static void convertCharsToStartingTiles(char[][] tableroInicial, Tile[][] starting, int h, int w) {
    if (board == null) { // Solo crear si no existe
        board = new shapes.Rectangle(h * TILE_SIZE, w * TILE_SIZE, 0, 0, "black");
        board.makeVisible();
    }
    int spacing = TILE_SIZE;  
    int finalOffsetX = w * TILE_SIZE + spacing; 
    if (endBoard == null) { // Solo crear si no existe
        endBoard = new shapes.Rectangle(h * TILE_SIZE, w * TILE_SIZE, finalOffsetX, 0, "black");
        endBoard.makeVisible();
    }
    for (int row = 0; row < h; row++) {
        for (int column = 0; column < w; column++) {
            char currentChar = tableroInicial[row][column];
            if (currentChar == '.') {
                starting[row][column] = null;
            } else {
                String color = getColorForTile(currentChar);
                starting[row][column] = new Tile(TILE_SIZE, TILE_SIZE, column * TILE_SIZE, row * TILE_SIZE, color, currentChar);
            }
        }
    }
}

    /**
     * Convierte un tablero de caracteres a objetos Tile para el tablero final.
     */
    public static void convertCharsToEndingTiles(char[][] tableroFinal, Tile[][] ending, int h, int w) {
        if (board == null) {
            board = new shapes.Rectangle(h * TILE_SIZE, w * TILE_SIZE, 0, 0, "black");
            board.makeVisible();
        }
        int spacing = TILE_SIZE;  
        int finalOffsetX = w * TILE_SIZE + spacing; 
        if(endBoard == null){
            endBoard = new shapes.Rectangle(h * TILE_SIZE, w * TILE_SIZE, finalOffsetX, 0, "black");
            endBoard.makeVisible();
        }
        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {
                char currentChar = tableroFinal[row][column];
                if (currentChar == '.') {
                    ending[row][column] = null;
                } else {
                    String color = getColorForTile(currentChar);
                    ending[row][column] = new Tile(TILE_SIZE, TILE_SIZE, column * TILE_SIZE + finalOffsetX, row * TILE_SIZE, color, currentChar);
                }
            }
        }
    }

    /**
     * Devuelve el color correspondiente a un carácter de pieza del rompecabezas.
     */
    public static String getColorForTile(char tileChar) {
        HashMap<String, Character> colorMap = new HashMap<>();

        colorMap.put("red", 'r');
        colorMap.put("black", ' ');
        colorMap.put("blue", 'b');
        colorMap.put("yellow", 'y');
        colorMap.put("green", 'g');
        colorMap.put("magenta", 'm');
        colorMap.put("white", ' ');  
        colorMap.put("cyan", 'c');
        colorMap.put("dark red", 'd');
        colorMap.put("purple", 'p');
        colorMap.put("orange", 'o');
        colorMap.put("salmon", 's');
        colorMap.put("amber", 'a');
        colorMap.put("emerald", 'e');
        colorMap.put("forest green", 'f');
        colorMap.put("honeydew", 'h');
        colorMap.put("indigo", 'i');
        colorMap.put("jade", 'j');
        colorMap.put("khaki", 'k');
        colorMap.put("lavender", 'l');
        colorMap.put("navajo white", 'n');
        colorMap.put("quartz pink", 'q');
        colorMap.put("teal", 't');
        colorMap.put("umber", 'u');
        colorMap.put("wine", 'w');
        colorMap.put("violet", 'v');
        colorMap.put("xanadu", 'x');
        colorMap.put("zucchini", 'z');
        for (Map.Entry<String, Character> entry : colorMap.entrySet()) {
        if (entry.getValue() == tileChar) {
            return entry.getKey();
        }
    }
        return "Unknown Color"; // Or return null if preferred
}
    /**
     * Inicializa el tablero `ending` con el rectángulo visible en una posición desplazada.
     */
    public static void initializeEndingBoard(Tile[][] ending,int h, int w, char color) {
        
        int spacing = TILE_SIZE;  
        int finalOffsetX = w * TILE_SIZE + spacing; 
        endBoard = new shapes.Rectangle(h * TILE_SIZE, w * TILE_SIZE, finalOffsetX, 0, "black");
        endBoard.makeVisible();
        for (int row = 0; row < h; row++) {
            for (int column = 0; column < w; column++) {
                ending[row][column] = null;
            }
        }
    }

    
    public static void makeInvisible(){
        board.makeInvisible();
        endBoard.makeInvisible();
    }
    public static void makeVisible(){
        board.makeVisible();
        endBoard.makeVisible();
    }
    
}



